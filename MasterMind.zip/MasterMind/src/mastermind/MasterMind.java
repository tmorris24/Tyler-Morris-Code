/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mastermind;

import core.Game;
import javax.swing.JOptionPane;
/**
 *
 * @author TMorr
 */
public class MasterMind {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // First Message for the console
        System.out.println("Welcome to Mastermind!");
        
        //Shows pop up message
        JOptionPane.showMessageDialog(null, "Let's Play Mastermind!");
        
        //Loads the game
        Game game = new Game();
    }
    
}
