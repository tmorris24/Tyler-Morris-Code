/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.awt.Color;
import java.util.ArrayList;
import Constants.Constants;
/**
 *
 * @author TMorr
 */
//Class that implements IGame
public class Game implements IGame{
    // Members Vars
    private int attempt;
    private Codebreaker codebreaker;
    private Codemaker codemaker;
//Getters and setters
    public int getAttempt() {
        return attempt;
    }

    public void setAttempt(int attempt) {
        this.attempt = attempt;
    }

    public Codebreaker getCodebreaker() {
        return codebreaker;
    }

    public void setCodebreaker(Codebreaker codebreaker) {
        this.codebreaker = codebreaker;
    }

    public Codemaker getCodemaker() {
        return codemaker;
    }

    public void setCodemaker(Codemaker codemaker) {
        this.codemaker = codemaker;
    }
    
    // Custom constructor
    public Game(){
        codemaker = new Codemaker();
        codebreaker = new Codebreaker();
        attempt = 0;
        play();
    }
    //Implemented in IGame
    public void play(){}
}
