/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.awt.Color;
import java.util.ArrayList;
import Constants.Constants;
/**
 *
 * @author TMorr
 */
//Create class that implements ICodebreaker
public class Codebreaker implements ICodebreaker{
    //member Vars
    private ArrayList<Color> codebreakerAttempt;
    
    //Constructor
    public Codebreaker(){
        codebreakerAttempt = new ArrayList();
    }
//Getters and setters
    public ArrayList<Color> getCodebreakerAttempt() {
        return codebreakerAttempt;
    }

    public void setCodebreakerAttempt(ArrayList<Color> codebreakerAttempt) {
        this.codebreakerAttempt = codebreakerAttempt;
    }
    //Implemented in ICodebreaker
    public void checkCode(ArrayList<Color> attempt){}
    
}
