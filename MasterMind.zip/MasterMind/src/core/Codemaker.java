/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import Constants.Constants;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
/**
 *
 * @author TMorr
 */

//Class that implements Icodemaker
public class Codemaker implements ICodemaker{
    //Member vars
    private Set<Color> secretCode;
    private ArrayList<Color> codemakerResponse;
//Customer constructor
    public Codemaker(){
        //Instantiate with HashSet
        secretCode = new HashSet();
        codemakerResponse = new ArrayList();
        //MethodCall
        generateSecretCode();
    }
    public void generateSecretCode(){
        //Load Random
        Random random = new Random();
        
        //While loop
        while(secretCode.size() < Constants.MAX_PEGS){
            int index = random.nextInt(Constants.COLORS);//Generates a random color
            Color selectedColor = Constants.codeColors.get(index);
            secretCode.add(selectedColor);
        }
        //Message for confirmation
        System.out.println("generated the secret code! ");

        for(Color color : secretCode){
            System.out.println(color.toString());
            //Print the code
        }
    }
//Getters and setters
    public Set<Color> getSecretCode() {
        return secretCode;
    }

    public void setSecretCode(Set<Color> secretCode) {
        this.secretCode = secretCode;
    }

    public ArrayList<Color> getCodemakerResponse() {
        return codemakerResponse;
    }
    public void setCodemakerResponse(ArrayList<Color> codemakerResponse) {
        this.codemakerResponse = codemakerResponse;
    }
//Override implemented in ICodemaker
    @Override
    public void checkAttemptedCode(ArrayList<Color> attempt) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
            
}
