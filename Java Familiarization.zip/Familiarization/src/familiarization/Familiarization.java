/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//Tyler Morris
//4826071
//COP 3330
//Familiarization Project
//06/05/19
package familiarization;

import java.util.Scanner;

/**
 *
 * @author TMorr
 */
public class Familiarization {
    
    static class Integer{}
    
    //Creating a global Scanner class
    
    static Scanner scnr;

    // Start of Arithmetic
    
    private static void arithmetic(){
        System.out.println("********** arithmetic **********");
        
        int numOne;
        int numTwo;
        
        //Get first integer
        
        System.out.println("Please enter a number greater than zero.");
        numOne = scnr.nextInt();
        
        // Get second integer
        
        System.out.println("Please enter another number greater than zero.");
        numTwo = scnr.nextInt();
        
        // Begin Arithmetic evaluations 
        
        System.out.print(numOne + " + " + numTwo + " = ");
        System.out.println(numOne + numTwo);
        
        System.out.print(numOne + " - " + numTwo + " = ");
        System.out.println(numOne - numTwo);
        
        System.out.print(numOne + " * " + numTwo + " = ");
        System.out.println(numOne * numTwo);
        
        System.out.print(numOne + " / " + numTwo + " = ");
        System.out.println(numOne / numTwo);
        
        System.out.print(numOne + " % " + numTwo + " = ");
        System.out.println(numOne % numTwo);
        
        // End of Arithmetic evaluations
    }
    
    //Start of Compound Assign
    
    private static void compoundAssign(){
        System.out.println("********** compundAssign **********");
        
        int numOne;
        int numTwo;
        int result;
        
        // Get first integer
        
        System.out.println("Please enter a number greater than zero.");
        numOne = scnr.nextInt();
        
        //Get second integer
        
        System.out.println("Please enter another number greater than zero.");
        numTwo = scnr.nextInt();
        
        // Set result = numOne
        
        result = numOne;
        
        //Begin of Compound Assign evaluations
        
        System.out.print("result += numTwo = ");
        System.out.println(result += numTwo);
        
        System.out.print("result -= numOne = ");
        System.out.println(result -= numOne);
        
        System.out.print("result *= numTwo = ");
        System.out.println(result *= numTwo);
        
        System.out.print("result /= numOne = ");
        System.out.println(result /= numOne);
        
        System.out.print("result %= numTwo = ");
        System.out.println(result %= numTwo);
        
        //End of Compound Assign evaluations
    }
    
    //Start of Unrary
    
    private static void unary(){
        System.out.println("********** unary **********");
        
        int num;
        
        //Get integer
        
        System.out.println("Enter a number greater than 0.");
        num = scnr.nextInt();
        
        //Begin Unary evaluations
        
        System.out.print("num-- = ");
        num--;
        System.out.println(num);
        
        System.out.print("num++ = ");
        num++;
        System.out.println(num);
        
        System.out.print("-num = ");
        num = -num;
        System.out.println(num);
        
        System.out.print("+num = ");
        num = +num;
        System.out.println(num);
        
        //End Unary evaluations
        
        //Begin Boolean evaluations 
        
        boolean success = true;
        
        System.out.print("Success = ");
        System.out.println(success);
        
        System.out.print("!Success = ");
        System.out.println(!success);
        
        //End Boolean evaluations
    }
    
        //Start Relational
    
    private static void relational(){
        System.out.println("********** relational **********");
        
        int numOne;
        int numTwo;
        
        //Get first Integer
        
        System.out.println("Please enter a number greater than zero.");
        numOne = scnr.nextInt();
        
        //Get second integer
        
        System.out.println("Please enter another number greater than zero.");
        numTwo = scnr.nextInt();
        
        //Begin Relational evaluations
        
        if(numOne == numTwo)
            System.out.println("numOne == numTwo");
        
        if(numOne != numTwo)
            System.out.println("numOne != numTwo");
        
        if(numOne > numTwo)
            System.out.println("numOne > numTwo");
        
        if(numOne >= numTwo)
            System.out.println("numOne >= numTwo");
        
        if(numOne < numTwo)
            System.out.println("numOne < numTwo");
        
        if(numOne <= numTwo)
            System.out.println("numOne <= numTwo");
        
        //End Relational evaluations
    }
    
    //Start Condtional 
    
    private static void conditional(){
        System.out.println("********** conditional **********");
        
        int numOne;
        int numTwo;
        
        //Get first integer >10
        
        System.out.println("Please enter a number greater than 10.");
        numOne = scnr.nextInt();
        
        //Get second intger >10
        
        System.out.println("Please enter another number greater than 10.");
        numTwo = scnr.nextInt();
        
        //Begin Conditional evaluations
        
        if((numOne >= 10) && (numTwo >= 10))
            System.out.println("numOne is >= 10 AND numTwo is >= 10");
        
        if((numOne >= 10) || (numTwo >= 10))
            System.out.println("numOne is >= 10 OR numTwo is >= 10");
        
        //End Conditional evaluations
    }
    
    //Start Instance Of
       
    private static void instanceOf(){
        System.out.println("********** instanceOf **********");
        
        int num;
        
        //Get an integer
        
        System.out.println("Enter a number greater than 0.");
        num = scnr.nextInt();
        
        //Assign num to Integer
        
        Integer classNum = new Integer();
        
        //Instance Of evaluation
        System.out.println("classNum instanceof Integer: " + (classNum instanceof Integer));
    }
    
        // Begin Main
    
    public static void main(String[] args) {
        
        //Instantiate Scanner
        
        scnr = new Scanner(System.in);
        
        // Call all other methods
        
        arithmetic();
        compoundAssign();
        unary();
        relational();
        conditional();
        instanceOf();
    }
    
}
