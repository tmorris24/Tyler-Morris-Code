package core;

import java.awt.Color;
import java.util.ArrayList;
import constants.Constants;
import java.util.Scanner;

public class Codebreaker implements ICodebreaker
{

// member variables
private ArrayList<Color> codebreakerAttempt;
//private Game game;
  
public Codebreaker()
{
// instanatiate the member variables
codebreakerAttempt = new ArrayList<>();
}
  
/**
* @return the codebreakerAttempt
*/
public ArrayList<Color> getCodebreakerAttempt()
{
// temporary code to test backend
//consoleAttempt();
return codebreakerAttempt;
}

/**
* @param codebreakerAttempt the codebreakerAttempt to set
*/
public void setCodebreakerAttempt(ArrayList<Color> codebreakerAttempt)
{
this.codebreakerAttempt = codebreakerAttempt;
}
  
@Override
public void checkCode(ArrayList<Color> attempt)
{
}

}

// empty the list
public void removeAll(){

if(!codebreakerAttempt.isEmpty()){
         codebreakerAttempt.clear();
    }

}