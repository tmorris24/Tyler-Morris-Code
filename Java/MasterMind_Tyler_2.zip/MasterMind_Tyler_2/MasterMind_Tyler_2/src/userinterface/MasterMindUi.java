/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface;

import core.Game;
import constants.Constants;

/**
 *
 * @author kwhiting
 */
public class MasterMindUi 
{
    private Game game;
    
    public MasterMindUi(Game game)
    {
        this.game = game;
        initComponents();
    }
    
    private void initComponents()
    {
        
    }
}
