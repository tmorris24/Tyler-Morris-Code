package core;

public interface IGame 
{
    public void play();
}
