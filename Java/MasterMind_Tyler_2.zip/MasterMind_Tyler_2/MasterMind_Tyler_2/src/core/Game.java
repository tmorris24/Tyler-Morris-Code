package core;

import constants.Constants;
import java.awt.Color;
import java.util.ArrayList;

public class Game implements IGame
{
    private int attempt;
    private Codebreaker codebreaker;
    private Codemaker codemaker;
    
    public Game()
    {
        codemaker = new Codemaker();
        codebreaker = new Codebreaker();
        attempt = 0;
        //Method call
        play();
    }
    //Create play
    public void play()
    {
        //Loop for max number of attempts
        while(true){
            if(attempt<Constants.MAX_ATTEMPTS){
                //Instantiate
                ArrayList<Color> codeBreakerAttempt=codebreaker.getCodebreakerAttempt();
                //Method call
                codemaker.checkAttemptedCode(codeBreakerAttempt);
                //Instantiate
                boolean win=codebreaker.checkCode(codemaker.getCodemakerResponse());
                if(win){
                    System.out.println("Codebreaker wins");
                    break; 
                }
            }
            else{
                System.out.println("Codemaker wins");
                break;
            }
            attempt++;
        }
        
    }

    public int getAttempt() {
        return attempt;
    }

    public void setAttempt(int attempt) {
        this.attempt = attempt;
    }

    public Codebreaker getCodebreaker() {
        return codebreaker;
    }

    public void setCodebreaker(Codebreaker codebreaker) {
        this.codebreaker = codebreaker;
    }

    public Codemaker getCodemaker() {
        return codemaker;
    }

    public void setCodemaker(Codemaker codemaker) {
        this.codemaker = codemaker;
    }
    public void checkIfWon(){
        
    }
}
