package core;

import java.awt.Color;
import java.util.ArrayList;

public interface ICodebreaker 
{
    public boolean checkCode(ArrayList<Color> attempt);
}
