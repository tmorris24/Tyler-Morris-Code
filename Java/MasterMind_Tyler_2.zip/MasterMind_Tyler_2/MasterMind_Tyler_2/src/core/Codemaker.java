package core;

import constants.Constants;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class Codemaker implements ICodemaker
{
    private Set<Color> secretCode;
    private ArrayList<Color> codemakerResponse;
    
    public Codemaker()
    {
        secretCode = new HashSet();     
        codemakerResponse = new ArrayList();
       
        generateSecretCode();
    }
    
    public void generateSecretCode()
    {
        Random random = new Random();
  
        while(secretCode.size() < Constants.MAX_PEGS)
        {
            int index = random.nextInt(Constants.COLORS);
            
            Color selectedColor = Constants.codeColors.get(index);
            
            secretCode.add(selectedColor);
        }
        
        System.out.println("generated the secret code! ");
        
        for(Color color : secretCode)
        {
            System.out.println(color.toString());
        }
        
    }
    
    public void checkAttemptedCode()
    {
        
    }
    public Set<Color> getSecretCode() 
    {
        return secretCode;
    }

    public void setSecretCode(Set<Color> secretCode) 
    {
        this.secretCode = secretCode;
    }

    public ArrayList<Color> getCodemakerResponse() 
    {
        return codemakerResponse;
    }

    public void setCodemakerResponse(ArrayList<Color> codemakerResponse) 
    {
        this.codemakerResponse = codemakerResponse;
    }
    
    public void checkAttemptedCode(ArrayList<Color> attempt) {

        codemakerResponse.clear();
        
        System.out.println("Codemaker checking attempted code");
        ArrayList<Integer> evaluatedPos=new ArrayList<Integer>();
        
        ArrayList<Integer> whitePegs=new ArrayList<Integer>(); 
        //Local vars for reg and white pegs
        int red_pegs=0,white_pegs=0;

        ArrayList<Color> secret=new ArrayList<Color>();

        secret.addAll(getSecretCode());
        //Check if exactly equal
        if(secret.equals(attempt)){
            
            red_pegs=4;

            white_pegs=0;

            for(int i=0;i<red_pegs;i++){

                codemakerResponse.add(Color.RED);
            }
        }
        //Determine the correct pegs
        else{
            for(int i=0;i<attempt.size();i++){

                if(secret.get(i).equals(attempt.get(i))){ 

                    red_pegs++;

                    evaluatedPos.add(i);
                }
                else{
                    if(secret.contains(attempt.get(i))){ 
                        white_pegs++;
                        whitePegs.add(i);
                    }
                }
            }
            
            for(int i=0;i<attempt.size();i++){
                if(evaluatedPos.contains(i)){
                    codemakerResponse.add(i, Color.RED);
                
                }
                else{
                    if(whitePegs.contains(i)){
                        codemakerResponse.add(i, Color.WHITE);
                    }
                    else{
                        codemakerResponse.add(i,null);
                    }
                }
            }
        }
    }
}
