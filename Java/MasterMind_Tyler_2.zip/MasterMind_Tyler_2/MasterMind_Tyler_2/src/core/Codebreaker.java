package core;

import java.awt.Color;
import java.util.ArrayList;
import constants.Constants;
import java.lang.reflect.Field;
import java.util.Scanner;

public class Codebreaker implements ICodebreaker
{
    private ArrayList<Color> codebreakerAttempt;
    
    public Codebreaker()
    {
        codebreakerAttempt = new ArrayList();
    }
    // Update for consoleAttempt - 2
    public ArrayList<Color> getCodebreakerAttempt() 
    {
        consoleAttempt();
        return codebreakerAttempt;
    }

    public void setCodebreakerAttempt(ArrayList<Color> codebreakerAttempt) 
    {
        this.codebreakerAttempt = codebreakerAttempt;
    }
    
    public boolean checkCode(ArrayList<Color> attempt){

        boolean errorMessage=false;

        for (Color color : attempt) {

            if(color!=Color.RED){ 

                errorMessage=true;

            }

        }
         if(errorMessage){

            System.out.println("Try again...");

            System.out.println("Right guesses in (positions)");

            for (int i=0;i<attempt.size();i++){

                if(attempt.get(i)==Color.RED){

                    System.out.print(i+" "); 

                }
            }
            
            System.out.println();

            System.out.println("Right colors,wrong positions in (positions)");

            for (int i=0;i<attempt.size();i++){
                if(attempt.get(i)==Color.WHITE){
                System.out.print(i+" "); 
                }
            }
        return false;
         }
         else {
                return true;
         }
    }
    
    //Add consoleAttempt - 1
    private void consoleAttempt(){

        boolean errorMessage=false; 
        //Remove previous data - 1a
        codebreakerAttempt.clear(); 
        //Scanner to take input - 1b
        Scanner scanner=new Scanner(System.in);
        //Prompt - 1c
        System.out.println("\nEnter your colors in left to right order\n" + "Use BLUE, BLACK, ORANGE, WHITE, YELLOW, RED, GREEN, PINK:");
        //Loop 1-d
        for(int i=0;i<Constants.MAX_PEGS;i++){
            //Changes lowercase letters to uppercase, since colors are coded using uppercase letters. - 1.D.i.1
            String colorString=scanner.next().toUpperCase();

            Color color=stringToColor(colorString);
            // If statement to check for color - 1.d.1.a.i
            if(color != null && !codebreakerAttempt.contains(color)){
            //Adds the color - 1.d.1.a.ii
            codebreakerAttempt.add(color);
            }
            else{
                System.out.println("wrong / duplicate colors");

                errorMessage=true;

                break;
            }
        }
        
        if(!errorMessage){

            System.out.println("Your input: ");
            //Enhanced For Loop - 1E
            for (Color col : codebreakerAttempt) {

                System.out.print(col+" ");

            }

            System.out.println();

        }
        
        else{

            consoleAttempt();
        }
                
    }
    private Color stringToColor(String colorString){

        Color color;

        try{
            
            Field field=Class.forName("java.awt.Color").getField(colorString);

            color=(Color)field.get(null);

        }
        catch(Exception e){

            color=null;

            }
        return color;
    }
}
