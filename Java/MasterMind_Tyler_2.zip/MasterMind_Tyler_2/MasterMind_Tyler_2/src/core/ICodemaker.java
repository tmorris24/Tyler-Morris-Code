package core;

import java.awt.Color;
import java.util.ArrayList;

public interface ICodemaker 
{
    
     public void generateSecretCode();
     //Modified CheckAttemptedCode
     public void checkAttemptedCode(ArrayList<Color> attempt);
}
