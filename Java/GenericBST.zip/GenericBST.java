// Tyler Morris
// COP 3503, Spring 2020

// ====================
// GenericBST: BST.java
// ====================
// Basic binary search tree (BST) with generic type implementation that supports insert() and
// delete() operations.


//Import of io and utilities packages that are used in this program.
import java.io.*;
import java.util.*;

// Creation of our general Node class to use used to store our information.
// Each Node holds a data value, and a left and right child.
class Node<AnyType extends Comparable<AnyType>>
{
	AnyType data;
	Node<AnyType> left, right;

//Method store data in the node.
	Node(AnyType data)
	{
		this.data = data;
	}
}

// Cration of our General Binary Search tree class. Holds all methods for creating and managing the tree.
// Methods in the class include insertion, deletion, creating a node, finding a max value,
// verifying if a value is contained in a program, and the three main tree traversal types.
public class GenericBST<AnyType extends Comparable<AnyType>>
{
	// Creation of our root node, set to NULL. Must be created in order to start the tree.
	private Node<AnyType> root;

	// Insertion of an element if the tree is empty, or the current "root" node is a leaf.
	public void insert(AnyType data)
	{
		root = insert(root, data);
	}

	// Our general insertion menthod used if there is/are elements in the tree
	// Uses the compareTo() method, which returns a value or 1, -1, or 0.
	// This value is then compared in order to determine if a node will be a left or right child of its parent.
	private Node<AnyType> insert(Node<AnyType> root, AnyType data)
	{
		if (root == null)
		{
			return new Node<AnyType>(data);
		}
		else if (root.data.compareTo(data) > 0)
		{
			root.left = insert(root.left, data);
		}
		else if (root.data.compareTo(data) < 0)
		{
			root.right = insert(root.right, data);
		}

		return root;
	}

	// Deletion method if the tree has just a root or the current "root" is a leaf node.
	public void delete(AnyType data)
	{
		root = delete(root, data);
	}

	// Standard Deletion method.
	// Like the Insertion method, it uses the same compareTo() method to decide how to traverse the tree to find the correct element.
	private Node<AnyType> delete(Node<AnyType> root, AnyType data)
	{
		if (root == null)
		{
			return null;
		}
		else if (root.data.compareTo(data) > 0)
		{
			root.left = delete(root.left, data);
		}
		else if (root.data.compareTo(data) < 0)
		{
			root.right = delete(root.right, data);
		}
		// This starts the logic flow of when we found our element. Since the previous flow checks if it's greater than or less than, or DNE.
		// We check to see if it's a leaf, or has only one child. We then delete the node, and move the subtree up if applicable.
		else
		{
			if (root.left == null && root.right == null)
			{
				return null;
			}
			else if (root.left == null)
			{
				return root.right;
			}
			else if (root.right == null)
			{
				return root.left;
			}
			// This part of the control flow is used when we have two subtrees on our deletion element.
			// We use findMax to find the maximum element of the left subtree.
			// We then replace our deletion node with that element, and then delete the element. The element is guaranteed to be a leaf with this method.
			else
			{
				root.data = findMax(root.left);
				root.left = delete(root.left, root.data);
			}
		}

		return root;
	}

	// This method assumes root is non-null, since this is only called by
	// delete() on the left subtree, and only when that subtree is not empty.

	// Finds the maxium element in the right subtree of the root.
	private AnyType findMax(Node<AnyType> root)
	{
		while (root.right != null)
		{
			root = root.right;
		}

		return root.data;
	}

	// Method to see if an element is in the tree.
	public boolean contains(AnyType data)
	{
		return contains(root, data);
	}

	// Standard contains mehtod. Used to see if an element exists in a tree.
	// Using the same compareTo() method, we check traverse the tree checking to see if an element is in the tree.
	private boolean contains(Node<AnyType> root, AnyType data)
	{
		if (root == null)
		{
			return false;
		}
		else if (root.data.compareTo(data) > 0)
		{
			return contains(root.left, data);
		}
		else if (root.data.compareTo(data) < 0)
		{
			return contains(root.right, data);
		}
		else
		{
			return true;
		}
	}

	// Standard Inorder traversal following LTR
	// The public version of this function is used for the program call. The private actually has the traversal and printing.
	public void inorder()
	{
		System.out.print("In-order Traversal:");
		inorder(root);
		System.out.println();
	}

	private void inorder(Node<AnyType> root)
	{
		if (root == null)
			return;

		inorder(root.left);
		System.out.print(" " + root.data);
		inorder(root.right);
	}

	// Standard Inorder traversal following TLR
	// The public version of this function is used for the program call. The private actually has the traversal and printing.
	public void preorder()
	{
		System.out.print("Pre-order Traversal:");
		preorder(root);
		System.out.println();
	}

	private void preorder(Node<AnyType> root)
	{
		if (root == null)
			return;

		System.out.print(" " + root.data);
		preorder(root.left);
		preorder(root.right);
	}

	// Standard Inorder traversal following LRT
	// The public version of this function is used for the program call. The private actually has the traversal and printing.
	public void postorder()
	{
		System.out.print("Post-order Traversal:");
		postorder(root);
		System.out.println();
	}

	private void postorder(Node<AnyType> root)
	{
		if (root == null)
			return;

		postorder(root.left);
		postorder(root.right);
		System.out.print(" " + root.data);
	}

	// Method to show how difficult this project was.
	public static double difficultyRating()
	{
		return 2.0;
	}

	// Method to show how many hours were spent on this project.
	public static double hoursSpent()
	{
		return 3;
	}

	public static void main(String [] args)
	{
	}
}
