// Tyler Morris
// COP 3503, Spring 2020, NID: 4826071

// ====================
// SneakyKnights.java
// ====================
// Simulation of a chess board with a check to see if coordinates with knights on them can attack other knights.


// Import of io and utilities packages that are used in this program.
import java.io.*;
import java.util.*;
import java.lang.*;
import java.awt.*;

public class SneakyKnights
{
    // Function to create a board using a HashSet. HashSet is useful here because it allows NULL values, doesn't auto initialize, and since we don't have duplicate Knights,
    // We don't need to worry about the set not taking duplicates.
    public static HashSet<Point> createBoard()
    {
        HashSet<Point> board = new HashSet<Point>();
        return board;
    }

    // Horners rule pulled from Webcourses, modified to take from an ArrayList in order to make getting characters to integers easier.
    public static int horner(ArrayList<Integer> a, int k)
    {
        int n = a.size();
        int retval = 0;

        for (int i = 0; i < n; i++)
        {
            retval *= k;
            retval += a.get(i);
        }

   return retval;
}
    // Method used to calculate the column value. Translates characters from the string to integers, and sends them to horner's rule to be converted to the final value.
    // This entire program runs with the idea that uppercase values are not used, however it can be modified to do so.
    public static int colCalc(String s)
    {
        ArrayList<Integer> array = new ArrayList<Integer>();
        for (int i = 0; i < s.length(); i++)
        {
            int test = (int)s.charAt(i);
            if (test > 96 && test < 123)
            {
                array.add(test - 96);
            }
        }
        return horner(array, 26);
    }

    // Like colCalc, this method is used to calculate the row value from a string. We do the same process, however we only take the integer characters.
    public static int rowCalc(String s)
    {
        ArrayList<Integer> array = new ArrayList<Integer>();
        for (int i = 0; i < s.length(); i++)
        {
            int test = (int)s.charAt(i);
            if (test > 47 && test < 58)
            {
                array.add(test - 48);
            }
        }
        return horner(array, 10);
    }

    // Takes our coordinates with Knights and puts them on the "board".
    public static HashSet<Point> popBoard(HashSet<Point>board, ArrayList<String> coList)
    {
        for (String s: coList)
        {
            int column = colCalc(s);
            int row = rowCalc(s);
            board.add(new Point(column, row));
        }
        return board;
    }

    // Our check to see if any single knight is safe. This method will be called k times, k being the number on knights.
    //There are eight checks total. Each one being the movements a knight can make.
    public static boolean KnightCheck(HashSet<Point>board, String knight)
    {
        if (board.contains(new Point(colCalc(knight) - 2,rowCalc(knight) + 1)))
        {
            return true;
        }
        if (board.contains(new Point(colCalc(knight) - 2, rowCalc(knight) - 1)))
        {
            return true;
        }
        if (board.contains(new Point(colCalc(knight) - 1, rowCalc(knight) + 2)))
        {
            return true;
        }
        if (board.contains(new Point(colCalc(knight) - 1,rowCalc(knight) - 2)))
        {
            return true;
        }
        if (board.contains(new Point(colCalc(knight) + 2, (rowCalc(knight) + 1))))
        {
            return true;
        }
        if (board.contains(new Point(colCalc(knight) + 2,rowCalc(knight) - 1)))
        {
            return true;
        }
        if (board.contains(new Point(colCalc(knight) + 1,rowCalc(knight) - 2)))
        {
            return true;
        }
        if (board.contains(new Point(colCalc(knight) + 1,rowCalc(knight) + 2)))
        {
            return true;
        }
        else
            return false;

    }

    // The method required by the PDF. Here we create a board, populate it, and then check one by one if each knight is safe or not.
    // This allows us to only ever have one knight beind used per string, instead of all knights at once.
    public static boolean allTheKnightsAreSafe(ArrayList<String> coordinateStrings, int boardSize)
    {
        HashSet<Point> board = createBoard();
        popBoard(board, coordinateStrings);
        for (String s : coordinateStrings)
        {
            if (KnightCheck(board, s)){
                return false;
            }
        }
        return true;
    }

    // Difficulty rating required by the PDF.
    public static double difficultyRating()
    {
        return 4.0;
    }

    // Hours Spent required by the PDF.
    public static double hoursSpent()
    {
        return 8.0;
    }

    // Main function.
    public static void main(String [] args) throws Exception
    {
    }
}
