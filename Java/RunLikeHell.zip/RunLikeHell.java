// Tyler Morris - COP 3503C - Spring 2020 -
// Ty224574

// ====================
// Run Like Hell : RunLikeHell.java
// ====================

import java.io.*;
import java.util.*;

public class RunLikeHell
{
	public static int maxGain(int [] blocks)
	{
		// variable to keep track of our total gain
		int gain = 0;
		for (int i = 0; i < blocks.length; i++)
		{
			// Base case 1 - Checks to see if we are at the final block in our list, in which case,
			// we jump to add it to the gain.
			if (i == blocks.length - 1)
			{
				gain += blocks[i];
				return gain;
			}

			// Base case 2 - Check to see if we are at the second to last block in our list, in which case,
			// we check to see which is greater. If the current is, add it, end break, because we can't
			// jump on any more blocks.
			if (i == blocks.length - 2)
			{
				if (blocks[i] >= blocks[i + 1])
				{
					gain += blocks[i];
					return gain;
				}
			}

			// All other cases
			else
			{
				// First we check to see if the current block is greater than the next block. If so, we
				// break the block, adding the ammount to our gain, and move forward two blocks.
				if (blocks[i] >= blocks[i + 1])
				{
					gain += blocks[i];
					i++;
				}
				// If not
				else
				{
					// We check to see if the next block's next block is greater than the next block.
					// So if pos 2 is < pos 3, if so we break the current block, adding the ammount to our gain,
					// and move forward two blocks.
					if (blocks[i + 1] <= blocks[i + 2])
					{
						gain += blocks[i];
						i++;
					}
				}

			}
		}
		return gain;
	}

// Standard difficultyRating method required by the assignment.
	public static double difficultyRating()
	{
		return 1.5;
	}

// Standard hoursSpent method required by the assignment.
	public static double hoursSpent()
	{
		return 2;
	}


	public static void main(String [] args) throws IOException
	{

	}
}
