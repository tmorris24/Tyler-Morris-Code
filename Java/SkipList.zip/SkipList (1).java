// Tyler Morris
// COP 3503, Spring 2020

// ====================
// GenericBST: BST.java
// ====================

// This is a This is a program using the Node and SkipList classes
// to implement the skiplist data structure taught in COP3503C.
// The skiplist is a powerful data structure that allows you to store things Like
// a linked list, however without having the O(n) runtime.

//  This implementation is generic, so it can take any type of object and create
// a skiplist of that object type, as long as the object is comparable.

import java.io.*;
import java.util.*;
import java.lang.*;
import java.awt.*;

// Our node class, it is used to create the containers for the skiplist. It has
// Three fields.
// A value - Used to store what is in the node.
// A height -  Used to store the height of this particular node.
// An ArrayList (pArray), used to store the pointers to the other nodes connected
// to this node.

class Node<AnyType extends Comparable<AnyType>>
{
	AnyType value;
	int height;
	ArrayList<Node<AnyType>> pArray = new ArrayList<Node<AnyType>>();

// These next two method are our constructors. They both initialize a new node.
// One is used when a value is not given, useful for creating a head node.
// The other is used when a value is given, used for all other nodes.

	Node(int height)
	{
		this.height = height;
		for (int i = 0; i < height; i++)
		this.pArray.add(i, null);
	}
	Node(AnyType value, int height)
	{
		this.value = value;
		this.height = height;
		for (int i = 0; i < height; i++)
		this.pArray.add(i, null);
	}

	// Method used to return the value stored in a node. Useful for when we need
	// The value of a node but do not want to change this value stored inside.

	public AnyType value()
	{
		return this.value;
	}

	// Method used to return the height stored in a node. Useful for when we need
	// The height of a node but do not want to change this height stored inside.

	public int height()
	{
		return this.height;
	}

	// This method finds and returns the next node at a given level of another node.

	public Node<AnyType> next(int level)
	{
		if (level < 0)
			return null;
		if (level > (this.height - 1))
			return null;
		return this.pArray.get(level);
	}

	// This method sets the next node at a given level of another node.

	public void setNext(int level, Node<AnyType> node)
	{
		this.pArray.set(level, node);
	}

	// This method guarantees a node to grow by a height of one.

	public void grow()
	{
		this.height++;
		this.pArray.add(null);
	}

	// This method gives a 50% chance for a node to grow. Useful for redistributing
	// The heights of a skiplist.

	public void maybeGrow(){
		Random rand = new Random();
		if ((rand.nextInt(2) % 2) == 0)
		{
			this.height++;
			this.pArray.add(null);
		}
	}

	// This method trims a node down to a given size. Used for rebalancing a list.

	public void trim(int inHeight)
	{
		while (this.pArray.size() > inHeight)
		{
			this.pArray.remove(this.pArray.size() - 1);
		}
		this.height = inHeight;
	}
}

// Our skiplist class. This class will allow us to create and manipulate a skiplist.
// This class has four fields
// A head node to mark the beginning of the list.
// A height, which should be the same as the height of the head.
// A size, used to determine the value that n (nodes) is.
// An ArrayList(currentPointers) used to mark the current furthest values of the list.

public class SkipList<AnyType extends Comparable<AnyType>>
{
	Node<AnyType> head;
	int height;
	int size = 0;
	ArrayList<Node<AnyType>> currentPointers = new ArrayList<Node<AnyType>>(height);

	// Our two constructors. They both initialize a new skiplist and a head node.
	// If not given a value, the first will be called. It will create a List
	// and head with a height of zero (1). If a height is given the skiplist will
	// be the same except with the list and head will have that value.

	SkipList()
	{
		this.head = new Node<AnyType>(1);
		this.height = 1;
		this.currentPointers.add(0, this.head);
	}
	SkipList(int height)
	{
		if (height <= 1)
		{
			this.head = new Node<AnyType>(1);
			this.height = 1;
			this.currentPointers.add(0, this.head);
		}
		else
		{
			this.head = new Node<AnyType>(height);
			this.height = height;
			for (int i = 0; i < height; i++)
			{
				this.currentPointers.add(i, this.head);
			}
		}
	}

	// Method that returns how many elements are in the list currently.

	public int size()
	{
		return this.size;
	}

	// Method that returns the height of the list currently.

	public int height()
	{
		return this.height;
	}

	// Method that returns the head of this list.

	public Node<AnyType> head()
	{
		return this.head;
	}

	// Method that finds the maximum height of a list due to the size restriction.
	// The size restriction will be ⌈log2n⌉.

	public int maxHeight(int size)
	{
		if (size < 2)
			return 1;
		double height = Math.log(size) / Math.log(2);
		height = Math.ceil(height);
		return (int)height;
	}

	// The insertion method for when the methd is just passed a value.
	// This method will create a node and give it a random height and store
	// the value passed.

	public void insert(AnyType data)
	{
		// Creating our random object to generate a random integer, and creating
		// our iterators.
		Random rand = new Random();
		int heightNew = 1;

		// Initial height determination. The height can only be less than final
		// value of bigHeight.
		int bigHeight = maxHeight(this.size);
		if (this.height> bigHeight)
			bigHeight = this.height;

		// The random height generator. This block will generate a 0 or 1. If
		// The number modded with 2 is 0, we increment the height. If not we
		// Stop and assign this value to the node. This is our virtual coin
		// flip to keep the distribution of heights weighted evenly.
		while(heightNew < bigHeight)
		{
			int randInt = (rand.nextInt(2) % 2);

			if(randInt % 2 == 0)
				heightNew++;
			else {
				break;
			}
		}

		// Insurance to make sure our head is the proper height.
		while (heightNew > this.head.height())
		{
			this.head.grow();
		}


		Node<AnyType> node = new Node<AnyType>(data, heightNew);
		Node<AnyType> temp = this.head;
		int height = this.head.height();

		// The searching algorithm to determine the location of our new node.
		// The algorithm first checks to see if the next node at the current level
		// is null. If so, we drop down a level.
		// Next it checks to see if the next node has a value greater than our
		// value we want to insert. If so, we drop a level.
		// Then it checks to see if the value of the next node is less than the
		// value we want to insert. If so we move our reference to that node.
		// Lastly we check to see if the next node's value is equal to the
		// value we want to insert. If so we treat it as if the node is greater
		// than our node and we drop down a level. This ensures the node will be
		// to the left of existing duplicates.
		while (height > 0)
		{
			if (temp.pArray.get(height - 1) == null)
			{
				this.currentPointers.set(height - 1, temp);
				height--;
			}
			else if (temp.pArray.get(height - 1).value().compareTo(data) > 0)
			{
				this.currentPointers.set(height - 1, temp);
				height --;
			}
			else if (temp.pArray.get(height - 1).value().compareTo(data) < 0)
			{
				temp = temp.pArray.get(height - 1);
			}
			else if (temp.pArray.get(height - 1).value().compareTo(data) == 0)
			{
				this.currentPointers.set(height - 1, temp);
				height--;
			}
		}

		// Here we start at the bottom level, connect the last visited node on
		// this level during our search, and then connect our inserted node to
		// the node which the previously mentioned was connected to.
		for (int i = 0; i < heightNew; i++)
		{
			node.pArray.set(i, this.currentPointers.get(i).pArray.get(i));
			this.currentPointers.get(i).pArray.set(i, node);
		}

		// Increment our table size.
		this.size++;

		// Here we check to see if our table needs to be resized (grow).
		if ((maxHeight(this.size) > bigHeight) && maxHeight(this.size) >= 2)
		{
			this.height++;
			this.currentPointers.add(null);
			this.head.grow();
			temp = this.head;
			Node<AnyType> temp2 = temp.next(this.height() - 2);

			// In this block, we iterate through the previous top level of the List
			// Then give each node a 50% chance to grow by one.
			// If it grows, we then link it with the last grown node.
			while (temp2 != null)
			{

				temp2.maybeGrow();
				if (temp2.height() == this.head.height())
				{
					temp.setNext(this.height() - 1, temp2);
				}
				if (temp2.height() == this.head.height())
				{
					temp = temp.next(this.height - 1);
					temp2 = temp2.next(this.height - 2);
				}
				else
					temp2 = temp2.next(this.height - 2);
			}
		}
	}

	// The second insertion method when we are passed a value and a fixed height.
	// It operates mostly the same as the previous method except taking into account
	// The fixed height.
	public void insert(AnyType data, int passHeight)
	{
		// Check to see if our table height is smaller than the new height.
		// If so we grow the table.
		if (passHeight > this.height)
		{
			this.height = passHeight;
			for (int i = this.currentPointers.size(); i < passHeight; i++)
			{
				this.currentPointers.add(null);
			}
		}

		// Our check to see if the table height should be the last passed height,
		// or the height determined by the size of the nodes.
		int bigHeight = maxHeight(this.size);
		if (this.height > bigHeight)
			bigHeight = this.height;

		// Inurance to make sure our head is of the proper height.
		while (passHeight > this.head.height())
		{
			this.head.grow();
		}

		Node<AnyType> node = new Node<AnyType>(data, passHeight);
		Node<AnyType> temp = this.head;
		int height = this.head.height();

		// The same searching algorithm as before.
		while (height > 0)
		{
			if (temp.pArray.get(height - 1) == null)
			{
				this.currentPointers.set(height - 1, temp);
				height--;
			}
			else if (temp.pArray.get(height - 1).value().compareTo(data) > 0)
			{
				this.currentPointers.set(height - 1, temp);
				height --;
			}
			else if (temp.pArray.get(height - 1).value().compareTo(data) < 0)
			{
				temp = temp.pArray.get(height - 1);
			}
			else if (temp.pArray.get(height - 1).value().compareTo(data) == 0)
			{
				this.currentPointers.set(height - 1, temp);
				height--;
			}
		}

		// The same insertion algorithm as before.
		for (int i = 0; i < passHeight; i++)
		{
			node.pArray.set(i, this.currentPointers.get(i).pArray.get(i));
			this.currentPointers.get(i).pArray.set(i, node);
		}

		this.size++;

		// The same resize algorithm as before.
		if ((maxHeight(this.size) > bigHeight) && maxHeight(this.size) >= 2)
		{
			this.height++;
			this.currentPointers.add(null);
			this.head.grow();
			temp = this.head;
			Node<AnyType> temp2 = temp.next(this.height() - 2);

			while(temp2 != null)
			{

				temp2.maybeGrow();
				if (temp2.height() == this.head.height())
				{
					temp.setNext(this.height() - 1, temp2);
				}
				if(temp2.height() == this.head.height())
				{
					temp = temp.next(this.height - 1);
					temp2 = temp2.next(this.height - 2);
				}
				else
					temp2 = temp2.next(this.height - 2);
			}
		}
	}

	// The method used to delete a node from the list. If so we will adjust Our
	// list and resize if necessary. If not we won't do anything.
	public void delete(AnyType data)
	{
		Node<AnyType> temp = this.head;
		int height = this.head.height();
		int deleteCheck = 0;

		// Our search algorithm for deletion. Similar to our insertion.
		// First, check if the next node is null. If so, store the current node
		// and drop down a level.
		// Next check if the next node is greater than our search value.
		// If so, store the current node, and drop down a level.
		// Then, check if the next node is less than our search value.
		// If so, move our reference to that value.
		// Lastly, check if the next value is equal to our search value.
		// If so, we store the current node andcheck if we've reached our ground
		// level. If we haven't, we decrement and move back to the top of the loop.
		// If we have, we move the reference to the next node and break the loop.
		while (height > 0)
		{
			if (temp.next(height - 1) == null)
			{
				this.currentPointers.set(height - 1, temp);
				height--;
			}
			else if (temp.pArray.get(height - 1).value().compareTo(data) > 0)
			{
				this.currentPointers.set(height - 1, temp);
				height--;
			}
			else if (temp.pArray.get(height - 1).value().compareTo(data) < 0)
			{
				temp = temp.next(height - 1);
			}
			else if (temp.next(height - 1).value().compareTo(data) == 0)
			{
				this.currentPointers.set(height - 1, temp);
				if (height >= 1)
				{
					height--;
				}
				else
				{
					temp = temp.next(0);
					break;
				}
			}
		}
		temp = temp.next(0);

		// Coming out of our search, our reference node either has to be our
		// Search value, or null.
		// If null we do nothing. Thus maintaining the state of the skiplist.
		if(temp == null)
		{

		}

		// If the value is our searched value, we connected the pointers pointing
		// to the search node to the pointers of the search node, and remove the
		// search node from the list. We decrement the list size, and signal the
		// Method that a node has been deleted.
		else if (temp.value().compareTo(data) == 0)
		{
			for (int i = 0; i < temp.height(); i++)
			{
				this.currentPointers.get(i).setNext(i, temp.next(i));
			}
			this.size--;
			deleteCheck++;
		}

		// When a node is deleted, this block will check to see if the list needs
		// to be resized. If so, we create two reference nodes.
		// One starts at the head, and another at the next node at the top level.
		// We then go into the loop. We push our second reference to the
		// Next node at this height, trim the current reference, and then
		// move the reference to the next node at the previous height.
		// The process is very much like a queue.
		if (((maxHeight(this.size()) < this.height()) && this.height() > 1) && (deleteCheck != 0))
		{
				Node<AnyType> temp2;
				while (this.height() > maxHeight(this.size()))
				{
				this.height--;
				this.currentPointers.remove(this.height);
				temp = this.head;
				temp2 = this.head.next(this.head.height());


				while (temp != null)
				{
					temp2 = temp.next(this.height);
					temp.trim(this.height);
					temp = temp2;
				}
				this.head.trim(this.height);
			}
		}
	}

	// Method to search and return a node with a given value. It uses the same
	// search algorithm as the deletion method, except for the equivalency control
	// portion, where we just assign that value to our reference and break the loop.
	public Node<AnyType> get(AnyType data)
	{
		Node<AnyType> temp = this.head;
		int height = this.head.height();

		while (height > 0)
		{
			if (temp.next(height - 1) == null)
			{
				height--;
			}
			else if (temp.pArray.get(height - 1).value().compareTo(data) > 0)
			{
				height--;
			}
			else if (temp.pArray.get(height - 1).value().compareTo(data) < 0)
			{
				temp = temp.next(height - 1);
			}
			else if (temp.next(height - 1).value().compareTo(data) == 0)
			{
				temp = temp.next(height - 1);
				break;
			}
		}

		// Check to see if the reference is our desired node. If so, return the node.
		// If not, return null.
		if (temp == null)
		{
			return null;
		}
		if (temp.value().compareTo(data) == 0)
		{
			return temp;
		}
		else
		{
			return null;
		}
	}

	// Method that uses the get method to see if a value is in the list. If so
	// We return true. If not, we return false.
	public boolean contains(AnyType data)
	{
		if (this.get(data) != null)
			return true;
		return false;
	}

	public static double difficultyRating()
	{
		return 4.5;
	}

	public static double hoursSpent()
	{
		return 26.0;
	}

	public static void main(String[] args)
	{

	}
}
