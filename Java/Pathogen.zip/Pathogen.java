// Tyler Morris
// Ty224574

// - Note! All commnts by me will begin with a - in order to differentiate from original file.


// =============================================================================
// Overview:
// =============================================================================
//
// You should modify the methods in this file to implement your backtracking
// solution for this assignment. You'll want to transform the solveMaze()
// methods into the findPaths() methods required for this assignment.
//
// =============================================================================
// Disclaimer:
// =============================================================================
//
// As usual, the comments in this file are way overkill. They're intended to be
// educational (and to make this code easier for you to work with), and are not
// indicative of the kind of comments we'd use in the real world.
//
// =============================================================================
// Maze Format (2D char array):
// =============================================================================
//
// This program assumes there is exactly one person ('@') and one exit ('e') per
// maze. The initial positions of those characters may vary from maze to maze.
//
// This program assumes all mazes are rectangular (all rows have the same
// length). There are no guarantees regarding the number of walls in the maze
// or the locations of those walls. It's possible that the outer edges of the
// maze might not be made up entirely of walls (i.e., the outer edge might
// contain spaces).
//
// While there is guaranteed to be a single person ('@') and a single exit ('e')
// in a well-formed maze, there is no guarantee that there exists a path from
// the starting position of the '@' character to the exit.
//
// =============================================================================
// Example:
// =============================================================================
//
// #############
// #@# #   #   #
// #   # # # # #
// # ### # # # #
// #     #   # #
// # ##### #####
// #          e#
// #############
//
// =============================================================================
// Legend:
// =============================================================================
//
// '#' - wall (not walkable)
// '@' - person
// 'e' - exit
// ' ' - space (walkable)


import java.io.*;
import java.util.*;

public class Pathogen
{
	// Used to toggle "animated" output on and off (for debugging purposes).
	private static boolean animationEnabled = false;

	// "Animation" frame rate (frames per second).
	private static double frameRate = 4.0;

	// Setters. Note that for testing purposes you can call enableAnimation()
	// from your backtracking method's wrapper method (i.e., the first line of
	// your public findPaths() method) if you want to override the fact that the
	// test cases are disabling animation. Just don't forget to remove that
	// method call before submitting!
	public static void enableAnimation() { Pathogen.animationEnabled = true; }
	public static void disableAnimation() { Pathogen.animationEnabled = false; }
	public static void setFrameRate(double fps) { Pathogen.frameRate = frameRate; }

	// - Added the virus character to the legend

	// Maze constants.
	private static final char WALL       = '#';
	private static final char VIRUS      = '*';
	private static final char PERSON     = '@';
	private static final char EXIT       = 'e';
	private static final char BREADCRUMB = '.';  // visited
	private static final char SPACE      = ' ';  // unvisited

	// Takes a 2D char maze and returns true if it can find a path from the
	// starting position to the exit. Assumes the maze is well-formed according
	// to the restrictions above.
	public static boolean solveMaze(char [][] maze, HashSet<String> MyPaths, StringBuilder CurPath)
	{
		int height = maze.length;
		int width = maze[0].length;

		// The visited array keeps track of visited positions. It also keeps
		// track of the exit, since the exit will be overwritten when the '@'
		// symbol covers it up in the maze[][] variable. Each cell contains one
		// of three values:
		//
		//   '.' -- visited
		//   ' ' -- unvisited
		//   'e' -- exit
		char [][] visited = new char[height][width];
		for (int i = 0; i < height; i++)
			Arrays.fill(visited[i], SPACE);

		// Find starting position (location of the '@' character).
		int startRow = -1;
		int startCol = -1;

		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width; j++)
			{
				if (maze[i][j] == PERSON)
				{
					startRow = i;
					startCol = j;
				}
			}
		}

		// Let's goooooooo!!
		return solveMaze(maze, visited, startRow, startCol, height, width, MyPaths, CurPath);
	}

	// - This method is where most of the work is. First off I added the Hashset and the Current Path
	// - stringbulder to the passed variables from our findPaths method.

	private static boolean solveMaze(char [][] maze, char [][] visited,
	                                 int currentRow, int currentCol,
	                                 int height, int width, HashSet<String> MyPaths,
									 StringBuilder CurPath)
	{
		// This conditional block prints the maze when a new move is made.
		if (Pathogen.animationEnabled)
		{
			printAndWait(maze, height, width, "Searching...", Pathogen.frameRate);
		}

		// Hooray!
		if (visited[currentRow][currentCol] == 'e')
		{
			// - Here I created a block to convert our stringbuilder to a string,
			// - and add it to the Hashset. This block will only occur when we have found the exit.

			String ValidPath = CurPath.substring(0, CurPath.length() - 1);
			MyPaths.add(ValidPath);
			if (Pathogen.animationEnabled)
			{
				char [] widgets = {'|', '/', '-', '\\', '|', '/', '-', '\\',
				                   '|', '/', '-', '\\', '|', '/', '-', '\\', '|'};

				for (int i = 0; i < widgets.length; i++)
				{
					maze[currentRow][currentCol] = widgets[i];
					printAndWait(maze, height, width, "Hooray!", 12.0);
				}

				maze[currentRow][currentCol] = PERSON;
				printAndWait(maze, height, width, "Hooray!", Pathogen.frameRate);
			}

			return true;
		}

		// Moves: left, right, up, down

		// - Added a string to cycle between letters to add to our string based on what direction we take

		int [][] moves = new int[][] {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};
		String moveLetters = "lrud";

		for (int i = 0; i < moves.length; i++)
		{
			int newRow = currentRow + moves[i][0];
			int newCol = currentCol + moves[i][1];

			// Check move is in bounds, not a wall, and not marked as visited.
			if (!isLegalMove(maze, visited, newRow, newCol, height, width))
				continue;

			// Change state. Before moving the person forward in the maze, we
			// need to check whether we're overwriting the exit. If so, save the
			// exit in the visited[][] array so we can actually detect that
			// we've gotten there.
			//
			// NOTE: THIS IS OVERKILL. We could just track the exit position's
			// row and column in two int variables. However, this approach makes
			// it easier to extend our code in the event that we want to be able
			// to handle multiple exits per maze.

			// - Here is where we add our direction to our string. Since the string has the same number of
			// - characters as moves, and in the same locations in their arrays, i will always correspond to
			// - the correct direction for both arrays.

			CurPath.append(moveLetters.charAt(i));
			CurPath.append(" ");
			if (maze[newRow][newCol] == EXIT)
				visited[newRow][newCol] = EXIT;


			// - These next three blocks have been modified so the program doesn't end after finding an exit
			// - and deletes the breadcrumbs. This is done so we can find every possible path, because we
			// - will take every legal direction combination.

			maze[currentRow][currentCol] = BREADCRUMB;
			visited[currentRow][currentCol] = BREADCRUMB;
			maze[newRow][newCol] = PERSON;


			// Perform recursive descent.
			if (solveMaze(maze, visited, newRow, newCol, height, width, MyPaths, CurPath))
			{
				//return true;
				maze[newRow][newCol] = EXIT;
				maze[currentRow][currentCol] = PERSON;
				visited[currentRow][currentCol] = SPACE;

				// - This deletes the characters from our string when backtracking.

				CurPath.deleteCharAt(CurPath.length() - 1);
				CurPath.deleteCharAt(CurPath.length() - 1);
			}

			// Undo state change. Note that if we return from the previous call,
			// we know visited[newRow][newCol] did not contain the exit, and
			// therefore already contains a breadcrumb, so I haven't updated
			// that here.
			else
			{
				maze[newRow][newCol] = SPACE;
				maze[currentRow][currentCol] = PERSON;
				visited[currentRow][currentCol] = SPACE;
				CurPath.deleteCharAt(CurPath.length() - 1);
				CurPath.deleteCharAt(CurPath.length() - 1);
			}

			// This conditional block prints the maze when a move gets undone
			// (which is effectively another kind of move).
			if (Pathogen.animationEnabled)
			{
				printAndWait(maze, height, width, "Backtracking...", frameRate);
			}
		}

		return false;
	}

	// Returns true if moving to row and col is legal (i.e., we have not visited
	// that position before, and it's not a wall).
	private static boolean isLegalMove(char [][] maze, char [][] visited,
	                                   int row, int col, int height, int width)
	{
		// - Added the virus to our conditions to return false. It basically is another wall.

		if (maze[row][col] == WALL || maze[row][col] == VIRUS || visited[row][col] == BREADCRUMB)
			return false;

		// - Added our maze's borders to the list of fail conditions. Created a second if statement
		// - for clarity.
		if (row == 0 || row == height-1 || col == 0 || col == width-1)
			return false;

		return true;
	}

	// This effectively pauses the program for waitTimeInSeconds seconds.
	private static void wait(double waitTimeInSeconds)
	{
		long startTime = System.nanoTime();
		long endTime = startTime + (long)(waitTimeInSeconds * 1e9);

		while (System.nanoTime() < endTime)
			;
	}

	// Prints maze and waits. frameRate is given in frames per second.
	private static void printAndWait(char [][] maze, int height, int width,
	                                 String header, double frameRate)
	{
		if (header != null && !header.equals(""))
			System.out.println(header);

		if (height < 1 || width < 1)
			return;

		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width; j++)
			{
				System.out.print(maze[i][j]);
			}

			System.out.println();
		}

		System.out.println();
		wait(1.0 / frameRate);
	}

	// Read maze from file. This function dangerously assumes the input file
	// exists and is well formatted according to the specification above.
	private static char [][] readMaze(String filename) throws IOException
	{
		Scanner in = new Scanner(new File(filename));

		int height = in.nextInt();
		int width = in.nextInt();

		char [][] maze = new char[height][];

		// After reading the integers, there's still a new line character we
		// need to do away with before we can continue.

		in.nextLine();

		for (int i = 0; i < height; i++)
		{
			// Explode out each line from the input file into a char array.
			maze[i] = in.nextLine().toCharArray();
		}

		return maze;
	}

	// - Our method to create our HashSet. It creates a Hashset, new stringbuilder, and passes them
	// - to our solve maze function. Once our paths are stored, it returns the set.
	public static HashSet<String> findPaths(char [][] maze)
	{
		HashSet<String> MyPaths = new HashSet<String>();
		StringBuilder CurPath = new StringBuilder(10);
		solveMaze(maze, MyPaths, CurPath);

		return MyPaths;
	}

	// - Diffuclty method required by project.

	public static double difficultyRating()
	{
		return 1.0;
	}

	// - Hours Spent method required by project.

	public static double hoursSpent()
	{
		return 3.0;
	}

	public static void main(String [] args) throws IOException
	{

	}
}
