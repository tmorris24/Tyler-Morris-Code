// Tyler Morris
// PID - 4826071

// ====================
// Constrained Topological Sort: ConstrainedTopoSort.java
// ====================

// This program reads a text file structed in the same order as given in the assignment PDF
// and reads it to create a directed graph. It then checks to see if the graph has a valid
// topological sort, which also checks to see if a particular node comes before a second node.
// Note: This program will NOT generate all sorts. It will only generate a particular sort,
// with the target node coming before the second node if possible.

import java.io.*;
import java.util.*;
import java.lang.*;
import java.awt.*;

// Our main class. We have four fields. A size field to tell us the number of nodes in the graph,
// a 2D - matrix to hold our edges, an ArrayList to store our sorted list, and another
// ArrayList used in the logic to check if a graph has a cycle.

public class ConstrainedTopoSort
{
	int size;
	int[][] adjMatrix;
	ArrayList<Integer> sortedList;
	ArrayList<Integer> cycleList;

// Our constructor method. It reads the file given and sets the size and adjacency matrix.
// For the edges, Java auto-initializes the array to all 0's. Reading the graph, incoming edges
// are set to 2, outgoing edges are set to 1.
// The constructor then creates a blank sorted list, and cycle list.

	public ConstrainedTopoSort(String filename) throws IOException
	{
		File graphFile = new File(filename);
		Scanner fileReader = new Scanner(graphFile);

		this.size = fileReader.nextInt();

		this.adjMatrix = new int[size][size];
		for (int i = 0; i < this.size; i++)
		{
			int numEdges = fileReader.nextInt();
			for (int j = 0; j < numEdges; j++)
			{
				int edge = (fileReader.nextInt()) - 1;
				this.adjMatrix[i][edge] = 1;
				this.adjMatrix[edge][i] = 2;
			}
		}

		this.sortedList = new ArrayList<Integer>(this.size);
		this.cycleList = new ArrayList<Integer>(this.size);
	}

// This method processes all nodes that come before our x node. We check to see if a node comes
// before our examined node. If it does, we go deeper into our recursive stack and add the node
// to the list to check for cycles. Once we have processed all of our nodes in comparison to
// the examined node, we add the node to the sorted list and break the call. If at any point we
// find a cycle in our graph, we break all the recursive calls back to the hasConstrainedTopoSort()
// method and return false.

	public boolean comesBefore(int check)
	{
		for (int i = 0; i < this.size; i++)
		{
			if (adjMatrix[check][i] == 2)
			{
				if (this.cycleList.contains(i) == false)
				{
					this.cycleList.add(i);
					if (comesBefore(i) == false)
					{
						return false;
					}

				}
				else
				{
					return false;
				}
			}
		}
		if (this.sortedList.contains(check + 1) == false)
			this.sortedList.add(check + 1);
		return true;
	}

// This method takes a node that comes after our target node. First we check for all nodes that
// come before the node. Then we add our node to the sorted list. Next we go check for nodes that
// come after the examined node, and go deeper into the recursive call. If at any point we find
// a cycle in our graph, we break the chain and return false.

	public boolean comesAfter(int check)
	{
		for (int i = 0; i < this.size; i++)
		{
			if (adjMatrix[check][i] == 2)
			{
				this.cycleList.add(i);
				if (comesBefore(i) == false)
					return false;
			}
			this.cycleList.clear();
		}

		if (this.sortedList.contains(check + 1) == false)
			this.sortedList.add(check + 1);

		for (int i = 0; i < this.size; i++)
		{
			if (adjMatrix[check][i] == 1)
			{
				if (comesAfter(i) == false)
					return false;
			}
			this.cycleList.clear();
		}
			return true;
	}

// This method is to process nodes that have no edge connected to our target node. This method
// behaves the same way as our hasConstrainedTopoSort, processing all cases that could define
// the node.

	public boolean Parallel(int check)
	{
		for (int i = 0; i < this.size; i++)
		{
			if (adjMatrix[check][i] == 2)
			{
				this.cycleList.add(i);
				if (comesBefore(i) == false)
					return false;
			}
			this.cycleList.clear();
		}

		if (this.sortedList.contains(check + 1) == false)
			this.sortedList.add(check + 1);

		for (int i = 0; i < this.size; i++)
		{
			if (adjMatrix[check][i] == 0)
			{
				if (this.sortedList.contains(i + 1) == false)
					if (Parallel(i) == false)
					{
						return false;
					}
			}
			this.cycleList.clear();
		}
		for (int i = 0; i < this.size; i++)
		{
			if (adjMatrix[check][i] == 1)
			{
				if (comesAfter(i) == false)
				{
					return false;
				}
			}
			this.cycleList.clear();
		}
		return true;
	}

// Our main method to see if the graph has a valid topological sort in which node x comes before
// node y. We begin by analyzing all nodes that come before the x node. We then begin a recurive
// call chain, placing the nodes that comes before into the sorted list. We then place the x node
// itself. Next we check all the nodes that don't have a edge between them, repeating this process.
// The last case is all the nodes that come after the x node. We begin a recursive call adding them
// to the list. At any point during this process if the algorithm detects a cycle, we break
// the algorithm and return false. Finally, with the x node being analyzed first, if we have
// a valid list, x will preceed y if it can. We check to see the index of x and see if it if
// it comes before the index of y in our list. If so we return true.

	public boolean hasConstrainedTopoSort(int x, int y)
	{
		for (int i = 0; i < this.size; i++)
		{
			if (adjMatrix[x - 1][i] == 2)
			{
				this.cycleList.add(i);
				if (comesBefore(i) == false)
				{
					return false;
				}
			}
			this.cycleList.clear();
		}

		if (this.sortedList.contains(x) == false)
			this.sortedList.add(x);

		for (int i = 0; i < this.size; i++)
		{
			if (adjMatrix[x - 1][i] == 0)
			{
				if (this.sortedList.contains(i + 1) == false)
					if (Parallel(i) == false)
					{
						return false;
					}
			}
			this.cycleList.clear();
		}

		for (int i = 0; i < this.size; i++)
		{
			if (adjMatrix[x - 1][i] == 1)
			{
				if (comesAfter(i) == false)
					return false;
			}
			this.cycleList.clear();
		}

		if (this.sortedList.indexOf(x) < this.sortedList.indexOf(y))
			return true;
		return false;
	}

// Standard difficultyRating method required by the assignment.

	public static double difficultyRating()
	{
		return 2.5;
	}

// Standard hoursSpent method required by the assignment.
	public static double hoursSpent()
	{
		return 4;
	}

	public static void main(String[] args) throws IOException
	{

	}
}
